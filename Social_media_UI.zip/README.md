# Social Media Scheduler Pro - Setup Guide

## Prerequisites
- Python 3.8+
- MongoDB installed and running on localhost:27017
- n8n webhook URL configured

## Installation Steps

### 1. Create Virtual Environment
```bash
python -m venv .venv
.venv\Scripts\activate  # On Windows
```

### 2. Install Dependencies
```bash
pip install -r requirements.txt
```

### 3. Configure Environment Variables
Create a `.env` file in the root directory (copy from `.env.example`):
```
MONGO_URL=mongodb://localhost:27017
N8N_WEBHOOK_URL=http://localhost:5678/webhook-test/fastapi-data
LOG_LEVEL=INFO
```

### 4. Verify MongoDB Connection
Make sure MongoDB is running:
```bash
mongod  # Start MongoDB service
```

### 5. Start the Application
```bash
uvicorn main:app --reload
```

Visit: http://localhost:8000

## Features

### 📝 Create & Schedule Posts
- Select media type (text, image, video, stories)
- Choose platform (Instagram, Facebook, or Both)
- Schedule immediately or set a custom time
- Posts are managed via MongoDB queue system
- APScheduler executes workflows at scheduled times

### 💾 Database Storage
- All scheduled posts saved to MongoDB
- Full history of published posts
- Stores media type, platform, URLs, and status

### 🔐 Account Management
- Save platform access tokens (Page & User tokens)
- Set token expiry dates
- Automatic expiry reminders (within 7 days)
- Manage multiple accounts per platform

### 🎨 Professional UI
- Modern, responsive design
- Gradient-based color scheme
- Tab-based navigation
- Real-time status updates
- Icon-rich interface

## Project Structure
```
main.py                 # FastAPI application with routes
database.py            # MongoDB connection & setup
models.py              # Pydantic models & database schemas
scheduler_queue.py     # APScheduler queue management
requirements.txt       # Python dependencies
templates/
  └── index.html       # Professional responsive UI
.env                   # Environment configuration
```

## API Endpoints

### Posts Management
- `GET /api/posts` - List all scheduled posts
- `POST /api/publish` - Create and schedule a new post
- `DELETE /api/posts/{post_id}` - Delete a scheduled post

### Accounts Management
- `GET /api/accounts` - List all saved accounts
- `POST /api/accounts` - Create new account
- `DELETE /api/accounts/{account_id}` - Delete account
- `GET /api/accounts/expiry-warnings` - Get expiring tokens

## Database Schema

### Scheduled Posts Collection
```json
{
  "_id": ObjectId,
  "media_type": "text|image|video|story_image|story_video",
  "platform": "instagram|facebook|both",
  "scheduled_time": datetime,
  "text_topic": string,
  "image_url": string,
  "video_url": string,
  "status": "pending|scheduled|published|failed",
  "created_at": datetime,
  "published_at": datetime,
  "error_message": string
}
```

### Accounts Collection
```json
{
  "_id": ObjectId,
  "platform": "instagram|facebook",
  "account_name": string,
  "page_access_token": string,
  "user_access_token": string,
  "token_expiry_date": datetime,
  "created_at": datetime,
  "is_active": boolean
}
```

## Future Enhancements

✅ Queue-based scheduling system (current)
✅ MongoDB data persistence (current)
✅ Web UI with navbar (current)
✅ Token expiry reminders (current)

📋 Advanced Features (to implement):
- Email notifications for token expiry
- Advanced analytics dashboard
- Bulk scheduling
- Multi-account posting
- Content preview before publishing
- Social media metrics integration
- Retry logic for failed posts

## Troubleshooting

**MongoDB Connection Error**
- Ensure MongoDB service is running
- Check `MONGO_URL` in `.env`
- Verify connection: `mongosh`

**n8n Webhook Not Receiving Posts**
- Check `N8N_WEBHOOK_URL` is correct
- Ensure n8n is running
- Check n8n logs for webhook errors

**Scheduled Posts Not Executing**
- Check APScheduler logs
- Verify system time is correct
- Monitor MongoDB for post status changes

## Support
For issues or questions, check the logs in the console output or MongoDB collections directly.
